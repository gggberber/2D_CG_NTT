# -*- coding: utf-8 -*-
"""
Created on Wed Jun 19 11:04:53 2024

@author: admin
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jun 17 20:38:30 2024

@author: admin
"""
import copy
import random
import math
import numpy
import sys
import os

from ntt_function import w_rom

#=============================== q_t =================================#      
k = (q).bit_length() 
q_t = (1 << (2 * k)) // q
#============================= q_t end ===============================#  

q  = 4294828033
q_t= 4295106563
N = 4096         

#=============================== ntt =================================# 
def DIT_NR_NTT(a,w_rom):
    n = len(a)
    log_n = int(math.log(n,2))
    r = 1       
    for p in range(log_n-1,-1,-1):
        J = int(pow(2,p))
        folder = 'python_data'
        filename = f"{'python_data'}_{N}_{p}_{'layer'}.{'txt'}"
        full_path = os.path.join(folder, filename)
        with open(full_path,"w") as f:   
            for k in range(int(n/(2*J))):
                w = w_rom[r] #1024 point
                r = r + 1                                
                for j in range(J):  
                    T = a[k*2*J+j+J]
                    U = T * w                    
                    z_shift = U >>(32-1)
                    mul2 = z_shift * q_t 
                    mul2_shift = mul2 >> (32+1)
                    mul3 = mul2_shift * q
                    sub = U - mul3
                    sub_low = sub & 0x1FFFFFFFF
                    if((sub_low - (2*q)) > 0):
                        V = sub_low - 2*q
                    elif((sub_low - q) > 0):
                        V = sub_low - q
                    else:
                        V = sub_low 
                    if(a[k*2*J+j] < V):
                        a[k*2*J+j+J] = a[k*2*J+j] + q - V
                    else:
                        a[k*2*J+j+J] = a[k*2*J+j] - V 
                    a[k*2*J+j] = a[k*2*J+j] + V
                    if(a[k*2*J+j] > q):
                        a[k*2*J+j] = a[k*2*J+j] - q 
            for i in range(N):
                print(a[i],file = f)
        f.close()
    return a
#=========================== ntt end  ===============================# 

#========================== comparison  =============================#  
def comparison(file1 ,file2): 
    f1 = open(file1, "r")
    txt1 = f1.read()
    f1.close()
    line1 = txt1.split()
    
    f2 = open(file2, "r")
    txt2 = f2.read()
    f2.close()
    line2 = txt2.split()
    txtlen = len(line1)
    line3 = copy.copy(line2)
    
    for i in range (0, txtlen, 16):
        line3[i+ 0] = line2[i+ 0]; line3[i+ 1] = line2[i+ 1];
        line3[i+ 2] = line2[i+ 8]; line3[i+ 3] = line2[i+ 9];
        
        line3[i+ 4] = line2[i+ 4]; line3[i+ 5] = line2[i+ 5];
        line3[i+ 6] = line2[i+12]; line3[i+ 7] = line2[i+13];
        
        line3[i+ 8] = line2[i+ 2]; line3[i+ 9] = line2[i+ 3];
        line3[i+10] = line2[i+10]; line3[i+11] = line2[i+11];
        
        line3[i+12] = line2[i+ 6]; line3[i+13] = line2[i+ 7];
        line3[i+14] = line2[i+14]; line3[i+15] = line2[i+15];
    
    comper_cnt = 0
    for i in range (txtlen): 
        if line1[i] != line3[i]:
            comper_cnt = comper_cnt + 1  
            print("line1= ",line1[i])
            print("line2= ",line2[i]) 
            print("i= ",i) 
            return comper_cnt
    print("comper_cnt = ", comper_cnt)
    return comper_cnt
#========================== comparison end  ============================#
  
a = [0] * N
for i in range(N):
    if(i < (N >> 1)):
        a[i]=0
    elif((N >> 1) <= i):
        a[i]=1
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
ffta = DIT_NR_NTT(a,w_rom)

folder1 = 'python_data'
filename1 = f"{'python_data'}_{4096}_{'0'}_{'layer.txt'}"
full_path1 = os.path.join(folder1, filename1)
folder2 = 'FPGA_data'
filename2 = f"{'FPGA_data'}_{4096}_{'0'}_{'layer.txt'}"
full_path2 = os.path.join(folder2, filename2)
comparison(full_path1 ,full_path2)


